package com.funo.footstone.eureka;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 服务中心
 */
@EnableEurekaServer
@SpringBootApplication
@RestController
public class BkEurekaApplication 
{

	public static void main(String[] args) 
	{
		SpringApplication.run(BkEurekaApplication.class, args);
	}
	
	/*
	http://localhost:8888/home
	 */
	@RequestMapping("/home")
    public String home() {
        return "BkEurekaHome";
    }
}
