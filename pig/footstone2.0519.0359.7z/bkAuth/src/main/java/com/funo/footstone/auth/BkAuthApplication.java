package com.funo.footstone.auth;


import com.funo.footstone.common.security.annotation.EnableBkFeignClients;
import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 认证授权中心
 */
@SpringCloudApplication
@EnableBkFeignClients
public class BkAuthApplication 
{

	public static void main(String[] args) 
	{
		SpringApplication.run(BkAuthApplication.class, args);
	}
	
	/*
	http://localhost:3000/home
	 */
	@RequestMapping("/home")
    public String home() {
        return "BkAuthHome";
    }
}
