package com.funo.footstone.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.funo.footstone.admin.api.entity.SysDict;

/**
 * 字典表 Mapper 接口
 */
public interface SysDictMapper extends BaseMapper<SysDict> {

}
