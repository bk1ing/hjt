package com.funo.footstone.admin.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.funo.footstone.admin.api.entity.SysOauthClientDetails;

/**
 * Mapper 接口
 */
public interface SysOauthClientDetailsMapper extends BaseMapper<SysOauthClientDetails> {

}
