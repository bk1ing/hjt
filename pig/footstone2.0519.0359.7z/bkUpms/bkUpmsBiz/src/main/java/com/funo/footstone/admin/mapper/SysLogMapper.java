package com.funo.footstone.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.funo.footstone.admin.api.entity.SysLog;

/**
 * 日志表 Mapper 接口
 */
public interface SysLogMapper extends BaseMapper<SysLog> {
}
