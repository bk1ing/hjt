package com.funo.footstone.admin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.funo.footstone.admin.api.entity.SysLog;

/**
 * 日志表 服务类
 */
public interface SysLogService extends IService<SysLog> {

}
