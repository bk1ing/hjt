package com.funo.footstone.zipkin;

import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import zipkin.storage.mysql.MySQLStorage;
import zipkin2.server.internal.EnableZipkinServer;

import javax.sql.DataSource;

/**
 * 服务链路追踪
 */
@EnableZipkinServer
@SpringCloudApplication

@RestController
public class BkZipkinApplication 
{
	public static void main(String[] args) 
	{
		SpringApplication.run(BkZipkinApplication.class, args);
	}

	@Bean
	public MySQLStorage mySQLStorage(DataSource datasource) 
	{
		return MySQLStorage.builder().datasource(datasource).executor(Runnable::run).build();
	}
	
	/*
	http://localhost:5002/home
	 */
	@RequestMapping("/home")
    public String home() 
	{
        return "BkZipkinHome";
    }
}
