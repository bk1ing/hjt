package com.funo.footstone.codegen;

import com.funo.footstone.common.security.annotation.EnableBkFeignClients;
import com.funo.footstone.common.security.annotation.EnableBkResourceServer;
import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 代码生成模块
 */
@EnableBkFeignClients
@EnableBkResourceServer
@SpringCloudApplication
public class BkCodeGenApplication {

	public static void main(String[] args) {
		SpringApplication.run(BkCodeGenApplication.class, args);
	}
	
	/*
	http://localhost:5001/home
	 */
	@RequestMapping("/home")
    public String home() 
	{
        return "BkCodeGenHome";
    }
}
