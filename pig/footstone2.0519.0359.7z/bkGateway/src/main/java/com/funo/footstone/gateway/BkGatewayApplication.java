package com.funo.footstone.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 网关应用
 */
@SpringCloudApplication

@RestController
public class BkGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(BkGatewayApplication.class, args);
	}
	
	/*
	http://localhost:9999/home
	 */
	@RequestMapping("/home")
    public String home() {
        return "BkGatewayHome";
    }
}
