package com.funo.footstone.common.core.exception;

import lombok.NoArgsConstructor;

/**
 * 403 授权拒绝
 */
@NoArgsConstructor
public class BkDeniedException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public BkDeniedException(String message) {
		super(message);
	}

	public BkDeniedException(Throwable cause) {
		super(cause);
	}

	public BkDeniedException(String message, Throwable cause) {
		super(message, cause);
	}

	public BkDeniedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
