package com.funo.footstone.common.security.annotation;

import com.funo.footstone.common.security.component.BkResourceServerAutoConfiguration;
import com.funo.footstone.common.security.component.BkSecurityBeanDefinitionRegistrar;
import org.springframework.context.annotation.Import;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;

import java.lang.annotation.*;

/**
 * 资源服务注解
 */
@Documented
@Inherited
@EnableResourceServer
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@EnableGlobalMethodSecurity(prePostEnabled = true)
@Import({BkResourceServerAutoConfiguration.class, BkSecurityBeanDefinitionRegistrar.class})
public @interface EnableBkResourceServer {

}
