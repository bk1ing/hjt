package com.funo.footstone.common.security.util;

import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class BCryptPasswordUtil
{
	public static void main(String[] args)
	{
/*		BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        System.out.println(bCryptPasswordEncoder.encode("123456"));
        System.out.println(bCryptPasswordEncoder.encode("17034642999"));
        */
		String password = "123456";//$2a$10$ofPkBDUezOJp6Sik63Q/0.QlU8a1itEyzldjSXqfn2nDPqXjN0Ljm
		String pwt = BCrypt.hashpw(password, BCrypt.gensalt());//加密
//		注：每次加密后的值都是不一样的
		
		boolean pswFlag = BCrypt.checkpw(password,"$2a$10$RpFJjxYiXdEsAGnWp/8fsOetMuOON96Ntk/Ym2M/RKRyU0GZseaDC");//解密

		System.out.println(pwt+"===="+pswFlag);
	}
}
