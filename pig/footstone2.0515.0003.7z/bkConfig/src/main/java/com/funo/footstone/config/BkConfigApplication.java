package com.funo.footstone.config;

import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.config.server.EnableConfigServer;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 配置中心
 */
@EnableConfigServer
@SpringCloudApplication
@RestController
public class BkConfigApplication 
{

	public static void main(String[] args) 
	{
		SpringApplication.run(BkConfigApplication.class, args);
	}
	
	/*
	http://localhost:8888/home
	 */
	@RequestMapping("/home")
    public String home() {
        return "BkConfigHome";
    }
}
