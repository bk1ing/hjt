package com.funo.footstone.admin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.funo.footstone.admin.api.entity.SysDict;

/**
 * 字典表 服务类
 */
public interface SysDictService extends IService<SysDict> {
}
