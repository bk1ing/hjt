package com.funo.footstone.admin.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.funo.footstone.admin.api.entity.SysLog;
import com.funo.footstone.admin.mapper.SysLogMapper;
import com.funo.footstone.admin.service.SysLogService;
import org.springframework.stereotype.Service;

/**
 * 日志表 服务实现类
 */
@Service
public class SysLogServiceImpl extends ServiceImpl<SysLogMapper, SysLog> implements SysLogService {

}
