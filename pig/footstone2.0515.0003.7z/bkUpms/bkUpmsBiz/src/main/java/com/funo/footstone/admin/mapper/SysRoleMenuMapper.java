package com.funo.footstone.admin.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.funo.footstone.admin.api.entity.SysRoleMenu;

/**
 * 角色菜单表 Mapper 接口
 */
public interface SysRoleMenuMapper extends BaseMapper<SysRoleMenu> {

}
