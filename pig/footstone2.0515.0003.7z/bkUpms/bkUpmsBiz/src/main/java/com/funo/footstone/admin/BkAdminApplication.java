package com.funo.footstone.admin;

import com.funo.footstone.common.security.annotation.EnableBkFeignClients;
import com.funo.footstone.common.security.annotation.EnableBkResourceServer;
import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/*
 */
@EnableBkResourceServer
@EnableBkFeignClients
@SpringCloudApplication
@RestController
public class BkAdminApplication 
{
	public static void main(String[] args) {
		SpringApplication.run(BkAdminApplication.class, args);
	}
	
	/*
	http://localhost:4000/home
	 */
	@RequestMapping("/home")
    public String home() {
        return "BkAdminHome";
    }
}
