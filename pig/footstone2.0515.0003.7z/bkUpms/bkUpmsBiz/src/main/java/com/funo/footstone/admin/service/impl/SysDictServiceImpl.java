package com.funo.footstone.admin.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.funo.footstone.admin.api.entity.SysDict;
import com.funo.footstone.admin.mapper.SysDictMapper;
import com.funo.footstone.admin.service.SysDictService;
import org.springframework.stereotype.Service;

/**
 * 字典表 服务实现类
 */
@Service
public class SysDictServiceImpl extends ServiceImpl<SysDictMapper, SysDict> implements SysDictService {

}
